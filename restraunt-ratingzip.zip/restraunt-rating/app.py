from flask import Flask, render_template
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score

app = Flask(__name__)

@app.route('/')
def index():
    # Load dataset
    df = pd.read_csv("Dataset .csv")

    # Select relevant features (adjust column names based on your dataset)
    features = ['City', 'Cuisines', 'Price range', 'Average Cost for two', 'Votes']
    target = 'Aggregate rating'

    # Encode categorical columns
    le_city = LabelEncoder()
    le_cuisine = LabelEncoder()
    df['City'] = le_city.fit_transform(df['City'].astype(str))
    df['Cuisines'] = le_cuisine.fit_transform(df['Cuisines'].astype(str))

    # Drop missing values
    df = df.dropna(subset=features + [target])

    X = df[features]
    y = df[target]

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Predictions
    y_pred = model.predict(X_test)

    # Metrics
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    # Feature importance
    feature_importances = dict(zip(features, model.feature_importances_))

    return render_template(
        "index.html",
        mse=round(mse, 2),
        r2=round(r2, 2),
        features=feature_importances
    )

if __name__ == "__main__":
    app.run(debug=True)
